import React from "react";
import Exchange from "./component/ExchangeLogic";

import "./App.css";
function App() {
  return (
    <>
      <Exchange />
     
   </>
    );
  }
  export default App;




